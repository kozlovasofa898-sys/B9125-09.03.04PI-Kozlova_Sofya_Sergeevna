#include "EquationSolver.h"
#include <cmath>

// ЛИНЕЙНОЕ
Result Linear(double a, double b) {
    Result res;
    res.num = 0;
    
    if (a == 0) {
        if (b == 0) {
            res.num = -1;   // бесконечно
        } else {
            res.num = 0;    // нет корней
        }
    } else {
        res.num = 1;
        res.kor[0] = -b / a;
    }
    return res;
}

// КВАДРАТНОЕ
Result Square(double a, double b, double c) {
    Result res;
    res.num = 0;
    
    if (a == 0) {
        return Linear(b, c);
    }
    
    double d = b * b - 4 * a * c;
    
    if (d < 0) {
        res.num = 0;
    } else if (d == 0) {
        res.num = 1;
        res.kor[0] = -b / (2 * a);
    } else {
        res.num = 2;
        res.kor[0] = (-b - sqrt(d)) / (2 * a);
        res.kor[1] = (-b + sqrt(d)) / (2 * a);
    }
    return res;
}

//БИКВАДРАТНОЕ
Result BiSquare(double a, double b, double c) {
    Result res;
    res.num = 0;
    
    if (a == 0) {
        Result r2 = Square(b, c, 0);
        int idx = 0;
        for (int i = 0; i < r2.num; i++) {
            double t = r2.kor[i];
            if (t > 0) {
                res.kor[idx++] = -sqrt(t);
                res.kor[idx++] = sqrt(t);
            } else if (t == 0) {
                res.kor[idx++] = 0;
            }
        }
        res.num = idx;
        return res;
    }
    
    double d = b * b - 4 * a * c;
    
    if (d < 0) {
        res.num = 0;
        return res;
    }
    
    double t1 = (-b - sqrt(d)) / (2 * a);
    double t2 = (-b + sqrt(d)) / (2 * a);
    
    int idx = 0;
    
    if (t1 > 0) {
        res.kor[idx++] = -sqrt(t1);
        res.kor[idx++] = sqrt(t1);
    } else if (t1 == 0) {
        res.kor[idx++] = 0;
    }
    
    if (t2 != t1) {
        if (t2 > 0) {
            res.kor[idx++] = -sqrt(t2);
            res.kor[idx++] = sqrt(t2);
        } else if (t2 == 0) {
            res.kor[idx++] = 0;
        }
    }
    
    // сортировка
    for (int i = 0; i < idx - 1; i++) {
        for (int j = i + 1; j < idx; j++) {
            if (res.kor[i] > res.kor[j]) {
                double tmp = res.kor[i];
                res.kor[i] = res.kor[j];
                res.kor[j] = tmp;
            }
        }
    }
    
    res.num = idx;
    return res;
}