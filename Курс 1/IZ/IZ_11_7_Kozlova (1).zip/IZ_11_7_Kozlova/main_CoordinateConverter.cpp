#include <iostream>
#include <iomanip>
#include "CoordinateConverter.h"

using namespace std;

int main() {
    cout << fixed << setprecision(4);
    
    //1. Декартовы → Полярные
    cout << "1. Cartesian -> Polar (2D)" << endl;
    Cartesian2D cart1 = {3.0, 4.0};
    Polar2D polar = CartesianToPolar(cart1);
    
    cout << "Input:  x = " << cart1.x << ", y = " << cart1.y << endl;
    cout << "Output: r = " << polar.r << ", phi = " << polar.phi << " rad" << endl;
    cout << endl;
    
    //2. Полярные → Декартовы 
    cout << "2. Polar -> Cartesian (2D)" << endl;
    Polar2D polar2 = {5.0, 1.0472};  // 1.0472 rad = 60°
    Cartesian2D cart2 = PolarToCartesian(polar2);
    
    cout << "Input:  r = " << polar2.r << ", phi = " << polar2.phi << " rad" << endl;
    cout << "Output: x = " << cart2.x << ", y = " << cart2.y << endl;
    cout << endl;
    
    //3. Декартовы → Сферические
    cout << "3. Cartesian -> Spherical (3D)" << endl;
    Cartesian3D cart3 = {1.0, 1.0, 1.0};
    Spherical3D sph = CartesianToSpherical(cart3);
    
    cout << "Input:  x = " << cart3.x << ", y = " << cart3.y << ", z = " << cart3.z << endl;
    cout << "Output: r = " << sph.r << ", theta = " << sph.theta << " rad, phi = " << sph.phi << " rad" << endl;
    cout << endl;
    
    // 4. Сферические → Декартовы
    cout << "4. Spherical -> Cartesian (3D)" << endl;
    Spherical3D sph2 = {1.732, 0.9553, 0.7854};
    Cartesian3D cart4 = SphericalToCartesian(sph2);
    
    cout << "Input:  r = " << sph2.r << ", theta = " << sph2.theta << " rad, phi = " << sph2.phi << " rad" << endl;
    cout << "Output: x = " << cart4.x << ", y = " << cart4.y << ", z = " << cart4.z << endl;
    cout << endl;
    
    return 0;
}