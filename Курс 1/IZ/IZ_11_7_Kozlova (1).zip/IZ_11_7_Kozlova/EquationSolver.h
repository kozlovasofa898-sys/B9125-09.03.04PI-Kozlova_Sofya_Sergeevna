#ifndef EQUATION_SOLVER_H
#define EQUATION_SOLVER_H

struct Result {
    int num;        // количество корней: 0,1,2,4 или -1 (бесконечно)
    double kor[4];  // массив корней
};

Result Linear(double a, double b);
Result Square(double a, double b, double c);
Result BiSquare(double a, double b, double c);

#endif