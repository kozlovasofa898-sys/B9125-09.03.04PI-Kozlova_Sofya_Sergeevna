#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <set>

using namespace std;

// запись для хранения одного разговора
struct Call {
    string op;      // оператор
    string num;     // номер телефона (11 цифр)
    int min;        // продолжительность разговора (минуты)
    float cost;     // стоимость минуты
};

int main() {
    // открываем файл
    ifstream f("calls.txt");
    
    // если файл не открылся
    if (!f.is_open()) {
        cout << "Ошибка: файл calls.txt не найден!" << endl;
        return 1;
    }
    
    // множество для проверки цифр в номере
    set<char> digits;
    for (char c = '0'; c <= '9'; c++) {
        digits.insert(c);
    }
    
    // хранилища всех данных
    map<string, set<string>> clients;   // оператор => клиенты
    map<string, float> profit;          // оператор => прибыль
    map<string, int> totalTime;         // абонент => общее время его разговоров
    
    // чтение файла
    string s;           // строка из файла
    int ok = 0;         // счётчик хороших записей
    int bad = 0;        // счётчик плохих записей
    int n = 0;          // номер строки
    
    cout << "=== Чтение файла ===" << endl;
    
    while (getline(f, s)) {
        n++;
        if (s.empty()) continue;
        
        // поиск разделителей ;
        int p1 = s.find(';');
        int p2 = s.find(';', p1 + 1);
        int p3 = s.find(';', p2 + 1);
        
        // проверяем формат строки
        if (p1 == -1 or p2 == -1 or p3 == -1) {
            cout << "Строка " << n << ": ошибка формата" << endl;
            bad++;
            continue;
        }
        
        // извлекаем 4 части из строки
        string op = s.substr(0, p1);
        string num = s.substr(p1 + 1, p2 - p1 - 1);
        string minS = s.substr(p2 + 1, p3 - p2 - 1);
        string costS = s.substr(p3 + 1);
        
        // проверяем номер
        bool numOk = true;
        
        if (num.length() != 11) {
            numOk = false;
        } else {
            bool allDig = true;
            for (char ccc : num) {
                if (digits.find(ccc) == digits.end()) {
                    allDig = false;
                }
            }
            numOk = allDig;
        }
        
        // проверяем оператора
        bool opOk = !op.empty();
        
        // проверяем минуты
        int m = 0;
        bool minOk = true;
        try {
            m = stoi(minS);
            if (m <= 0) minOk = false;
        } catch (...) {
            minOk = false;
        }
        
        // проверяем стоимость
        float c = 0;
        bool costOk = true;
        try {
            c = stof(costS);
            if (c <= 0) costOk = false;
        } catch (...) {
            costOk = false;
        }
        
        // все хорошо => сохраняем
        if (opOk && numOk && minOk && costOk) {
            ok++;
            
            // добавляем клиента оператору
            clients[op].insert(num);
            
            // добавляем прибыль оператору
            profit[op] += m * c;
            
            // добавляем время абоненту
            totalTime[num] += m;
            
            cout << "OK: " << op << " " << num << " " << m << "мин " << c << "руб" << endl;
        } else {
            bad++;
            cout << "Ошибка в строке " << n << ": " << s << endl;
        }
    }
    
    f.close();
    
    cout << "\n=== Итоги ===" << endl;
    cout << "Хороших: " << ok << endl;
    cout << "Плохих: " << bad << endl;
    
    if (ok == 0) {
        cout << "Нет данных для анализа!" << endl;
        return 1;
    }
   
    // оператор с наибольшим числом клиентов
    string bestOp1;
    int maxCli = 0;
    
    for (auto it = clients.begin(); it != clients.end(); ++it) {
        int cnt = it->second.size();
        if (cnt > maxCli) {
            maxCli = cnt;
            bestOp1 = it->first;
        }
    }

    // у кого наибольшая прибыль
    string bestOp2;
    float maxProf = 0;
    
    for (auto it = profit.begin(); it != profit.end(); ++it) {
        if (it->second > maxProf) {
            maxProf = it->second;
            bestOp2 = it->first;
        }
    }
    
    // самый "болтливый" абонент
    string bestNum;
    int maxTime = 0;
    
    for (auto it = totalTime.begin(); it != totalTime.end(); ++it) {
        if (it->second > maxTime) {
            maxTime = it->second;
            bestNum = it->first;
        }
    }
  
    // вывод результатов
    cout << "\n=== Результаты ===" << endl;
    cout << "1. Оператор с наибольшим числом клиентов: " << bestOp1 << " (" << maxCli << ")" << endl;
    cout << "2. Компания с наибольшей прибылью: " << bestOp2 << " (" << maxProf << " руб)" << endl;
    cout << "3. Самый болтливый абонент: " << bestNum << " (" << maxTime << " мин)" << endl;
    
    return 0;
}